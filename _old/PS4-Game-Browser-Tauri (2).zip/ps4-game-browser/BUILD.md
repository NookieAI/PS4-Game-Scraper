# PS4 Game Browser — Tauri Build Instructions

## Prerequisites (one-time setup)

### 1. Install Rust
```
winget install Rustlang.Rustup
```
Or download from https://rustup.rs — click through defaults.

### 2. Install WebView2 (already installed on Windows 10/11 — skip if unsure)
https://developer.microsoft.com/en-us/microsoft-edge/webview2/

### 3. Install Visual Studio C++ Build Tools
```
winget install Microsoft.VisualStudio.2022.BuildTools
```
During install tick: "Desktop development with C++"

### 4. Install the Tauri CLI
```
cargo install tauri-cli --version "^1"
```

---

## One-time: set your CDN URL

Open `ui/index.html` and replace the placeholder on this line:

```js
const CDN = 'YOUR_PS4_CDN_URL';
```

with your R2 bucket's public URL, e.g.:

```js
const CDN = 'https://pub-XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.r2.dev';
```

You get this URL from the Cloudflare R2 dashboard → your `ps4` bucket → Settings → Public access.

---

## Project structure

```
ps4-game-browser/
├── ui/
│   └── index.html          ← frontend (edit this for UI changes)
├── BUILD.md                ← this file
├── .github/
│   └── workflows/
│       └── build.yml       ← GitHub Actions CI/CD
└── src-tauri/
    ├── src/
    │   └── main.rs         ← Rust backend (minimal — leave alone)
    ├── Cargo.toml
    ├── build.rs
    ├── tauri.conf.json     ← app config (window size, allowlist, bundle)
    └── icons/              ← icon files
```

---

## Icons

Put your icon files in `src-tauri/icons/`. Tauri expects:

| File                    | Size    |
|-------------------------|---------|
| `icons/32x32.png`       | 32×32   |
| `icons/128x128.png`     | 128×128 |
| `icons/128x128@2x.png`  | 256×256 |
| `icons/icon.icns`       | macOS   |
| `icons/icon.ico`        | Windows |

**Quickest way** — generate all sizes from a single PNG:
```
cargo tauri icon path/to/your-icon.png
```

---

## Build

### Development (live preview)
```
cargo tauri dev
```

### Production build
```
cargo tauri build
```

Output: `src-tauri/target/release/bundle/`
- **NSIS installer:** `nsis/PS4 Game Browser_1.0.0_x64-setup.exe`
- **Raw portable exe:** `src-tauri/target/release/ps4-game-browser.exe`

The raw `.exe` is fully portable. WebView2 must be installed (pre-installed on Win10/11).

---

## What's baked in vs what comes from the CDN

| Thing                | Where          | How to update              |
|----------------------|----------------|----------------------------|
| Window / Rust shell  | Inside the exe | Rebuild                    |
| UI (index.html)      | Inside the exe | Rebuild                    |
| `ui_patch.css`       | R2 CDN         | Upload file, instant       |
| `ui_patch.js`        | R2 CDN         | Upload file, instant       |
| `games_cache.json`   | R2 CDN         | Scraper uploads after run  |
| Game images          | R2 CDN         | Scraper uploads after run  |

---

## R2 bucket layout

```
ps4/                               ← bucket root
├── games_cache.json               ← data (required — uploaded by scraper)
├── ui_patch.css                   ← remote CSS patch (optional)
├── ui_patch.js                    ← remote JS patch  (optional)
├── screenshots/
│   ├── CUSA12345-game-slug/
│   │   ├── cover_CUSA12345.jpg
│   │   ├── screenshot_1_CUSA12345.jpg
│   │   └── screenshot_2_CUSA12345.jpg
│   └── ... (one folder per game, created by scraper)
└── games.json                     ← URL list (used by scraper, not browser)
```

---

## Scraper ↔ Browser data flow

```
scraper_ps4_v2.py
    │  runs, scrapes dlpsgame.com
    │  writes: games.json, games_cache.json, screenshots/
    ▼
run_scraper_and_upload.bat
    │  uploads everything to r2:ps4/
    ▼
Cloudflare R2 (ps4 bucket)
    │  serves via public CDN URL
    ▼
PS4 Game Browser (this app)
    │  fetches games_cache.json on launch
    │  fetches screenshots on demand
    │  opens download links in system browser
```

---

## Updating the UI remotely (no rebuild needed)

Upload `ui_patch.css` or `ui_patch.js` to the R2 bucket root.
Every user gets the change on next app launch.

Available hooks in `ui_patch.js` via `window.UIHooks`:
- `UIHooks.populateModal(game, data, els)` — replace entire modal render
- `UIHooks.buildMetaBadges(meta)` → HTML string
- `UIHooks.buildDescription(data)` → HTML string
- `UIHooks.buildVersionBlocks(versions, data)` → HTML string
- `UIHooks.afterModalPopulated(game, data, els)` — post-render hook
